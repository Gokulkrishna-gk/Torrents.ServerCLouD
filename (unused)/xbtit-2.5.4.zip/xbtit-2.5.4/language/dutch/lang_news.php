<?php
$language["ERR_NO_TITLE"]="U moet een titel voor het nieuws opgeven!";
?>