<?php
$language["ERR_NO_EMAIL"]="U moet een email adres opgeven!";
$language["ERR_INV_EMAIL"]="U moet een geldig email adres opgeven!";
$language["ERR_NO_CAPTCHA"]="U moet de FotoCode invullen!";
$language["IMAGE_CODE"]="FotoCode";
$language["SECURITY_CODE"]="Beantwoord de vraag";
$language["RECOVER_EMAIL_1"]="\nIemand, hopelijk u, heeft gevraagd dat het wachtwoord voor het account gelinkt aan dit emailadres (%s) gerest kon worden.\n\nHet verzoek kwam van %s.\n\nAls u dit niet gedaan heeft, negeer dan deze email. Alstublieft niet reageren.\n\nZou u dit verzoek willen bevestigen, volg dan deze link:\n\n%s\n\nNadat u dit gedaan heeft, zal uw wachtwoord gereset worden en zal u opnieuw een email ontvangen.\n--\n%s";
$language["RECOVER_EMAIL_2"]="\nWij hebben op uw verzoek een nieuw wachtwoord aangemaakt voor uw account.\n\nHier is de informatie die nu ingesteld staat voor dit account:\n\n    Gebruikersnaam: %s\n    Wachtwoord: %s\n\nU kunt inloggen op %s\n\n--\n%s";
?>