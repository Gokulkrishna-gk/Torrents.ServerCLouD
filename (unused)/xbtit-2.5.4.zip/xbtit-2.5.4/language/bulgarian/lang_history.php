<?php
$language["PEER_PROGRESS"]="Прогрес";
$language["PEER_COUNTRY"]="Държава";
$language["PEER_PORT"]="Порт";
$language["PEER_STATUS"]="Статус";
$language["PEER_CLIENT"]="Клиент";
$language["NO_HISTORY"]="Няма история за показване";
?>