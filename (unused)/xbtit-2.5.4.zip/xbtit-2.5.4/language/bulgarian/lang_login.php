<?php
$language["INSERT_USERNAME"]="Трябва да въведете потребителско име!";
$language["INSERT_PASSWORD"]="Трябва да въведете парола!";
?>