<?php
$language["DELETE_READED"]="Изтрий";
$language["USER_LANGUE"]="Език";
$language["USER_STYLE"]="Стил";
$language["CURRENTLY_PEER"]="В момента сийдвате или лийчвате торенти.";
$language["STOP_PEER"]="Трябва да спрете своя клиент.";
$language["USER_PWD_AGAIN"]="Повторете паролата";
$language["EMAIL_FAILED"]="Изпращането на E-mail се провали!";
$language["NO_SUBJECT"]="Няма тема";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>Трябва да въведете своята парола, за да промените настройките по-горе.</strong></font>";
$language["ERR_PASS_WRONG"]="Паролата е грешна.";
$language["MSG_DEL_ALL_PM"]="Ако изберете съобщения, които не са прочетени, те няма да бъдат изтрити.";
$language["ERR_PM_GUEST"]="Съжаляваме, не можете да изпращате Лични Съобщения на Гост или на себе си!";
?>