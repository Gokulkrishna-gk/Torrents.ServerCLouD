<?php
$language["NOT_SHA"]="SHA1 функцията е недостъпна. Трябва ви PHP с версия 4.3.0 или по-нова.";
$language["NOT_AUTHORIZED_UPLOAD"]="Нямате права за качване!";
$language["FILE_UPLOAD_ERROR_1"]="Не мога да разчета качения файл";
$language["FILE_UPLOAD_ERROR_3"]="Файлът е с нулева големина!";
$language["FACOLTATIVE"]="Незадължителен";
$language["FILE_UPLOAD_ERROR_2"]="Грешка при качване на файла.";
$language["ERR_PARSER"]="Изглежда има някаква грешка във Вашия торент.";
$language["WRITE_CATEGORY"]="Трябва да изберете категория на торента";
$language["DOWNLOAD"]="Свали";
$language["MSG_UP_SUCCESS"]="Качването е успешно! Торентът е добавен.";
$language["MSG_DOWNLOAD_PID"]="PID системата е активна. Вземете торента от вашия PID";
$language["EMPTY_DESCRIPTION"]="Трябва да въведете описание!";
$language["EMPTY_ANNOUNCE"]="Анонсът на торент-файла е празен";
$language["FILE_UPLOAD_ERROR_1"]="Не мога да разчета качения файл";
$language["FILE_UPLOAD_ERROR_2"]="Грешка при качването на файла.";
$language["FILE_UPLOAD_ERROR_3"]="Файлът е с нулева големина";
$language["NO_SHA_NO_UP"]="Качването на файлове не е достъпно - няма SHA1 функция.";
$language["NOT_SHA"]="SHA1 функцията е недостъпна. Трябва ви PHP с версия 4.3.0 или по-нова.";
$language["ERR_PARSER"]="Изглежда има някаква грешка при качване на файла.";
$language["WRITE_CATEGORY"]="Трябва да изберете категория на торента...";
$language["ERR_HASH"]="Инфо-хаша трябва да е точно 40 hex bytes.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Външните торенти са забранени";
$language["ERR_MOVING_TORR"]="Грешка при местенето на торента...";
$language["ERR_ALREADY_EXIST"]="Този торент вече съществува в нашата база данни.";
$language["MSG_DOWNLOAD_PID"]="PID системата е активна. Вземете торента от вашия PID";
$language["MSG_UP_SUCCESS"]="Качването е успешно! Торентът е добавен.";

?>