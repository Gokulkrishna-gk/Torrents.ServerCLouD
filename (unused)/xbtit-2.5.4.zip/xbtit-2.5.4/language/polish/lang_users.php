<?php

// ENGLISH USERS.PHP FILE

$language["FIND_USER"]="Znajdź użytkownika";
$language["USER_LEVEL"]="Ranga użytkownika";
$language["ALL"]="Wszyscy";
$language["SEARCH"]="Szukaj";
$language["USER_NAME"]="Nazwa użytkownika";
$language["USER_LEVEL"]="Ranga użytkownika";
$language["USER_JOINED"]="Dołączył";
$language["USER_LASTACCESS"]="Ostatnie logowanie";
$language["USER_COUNTRY"]="Kraj";
$language["RATIO"]="Ratio";
$language["USERS_PM"]="PM";
$language["EDIT"]="Edytuj";
$language["DELETE"]="Usuń";
$language["NO_USERS_FOUND"]="Nie znaleziono użytkownika!";
$language["UNKNOWN"]="Nieznany";

?>