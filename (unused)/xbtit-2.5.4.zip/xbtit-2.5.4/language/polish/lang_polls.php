<?php
//AJAX Poll System Hack Start - 5:03 PM 3/24/2007
$language["POLL_ID"]="ID";
$language["LATEST_POLL"]="Najnowsza ankieta";
$language["CAST_VOTE"]="Głosuj!";

$language["FETCHING_RESULTS"]="Pobieranie wyników ankiety. Proszę czekać...";
$language["POLL_TITLE"]="Tytuł ankiety";
$language["POLL_TITLE_MISSING"]="Brakuje tytułu ankiety";
$language["POLLING_SYSTEM"]="System Ankiet AJAX";
$language["CURRENT_POLLS"]="Aktualne ankiety";
$language["POLL_STARTED"]="Rozpoczęta dnia";
$language["POLL_ENDED"]="Zakończona dnia";
$language["POLL_LASTED"]="Okres trwania";
$language["POLL_BY"]="Rozpoczęta przez";
$language["POLL_VOTES"]="Głosów";
$language["POLL_STILL_ACTIVE"]="Nadal aktywna";
$language["POLL_NEW"]="Nowa";
$language["POLL_START_NEW"]="Włącz nową ankietę";
$language["POLL_ACTIVE"]="Aktywna";
$language["POLL_ACTIVE_TRUE"]="Aktywna";
$language["POLL_ACTIVE_FALSE"]="Nieaktywna";
$language["POLL_OPTION"]="Opcja";
$language["POLL_OPTIONS"]="Opcje";
$language["POLL_MOVE"]="Przenieś niżej";
$language["POLL_NEW_OPTIONS"]="Nowe opcje";
$language["POLL_SAVE"]="Zapisz";
$language["POLL_CANCEL"]="Anuluj";
$language["POLL_DELETE"]="Usuń";
$language["POLL_DEL_CONFIRM"]="Kliknij OK, aby usunąć tę ankietę";
$language["POLL_VOTERS"]="Głosujący";
$language["POLL_IP_ADDRESS"]="Adres IP";
$language["POLL_DATE"]="Data";
$language["POLL_USER"]="Użytkownik";
$language["POLL_ACCOUNT_DEL"]="<i>konto usunięte</i>";
$language["POLL_BACK"]="Wstecz";
$language["YEAR"]="rok";
$language["MONTH"]="miesiąc";
$language["WEEK"]="tydzień";
$language["DAY"]="dzień";
$language["HOUR"]="godzina";
$language["MINUTE"]="minuta";
$language["SECOND"]="sekunda";
$language["YEARS"]="lat(a)";
$language["MONTHS"]="miesiące/-y";
$language["WEEKS"]="tygodni(e)";
$language["DAYS"]="dni";
$language["HOURS"]="godzin(y)";
$language["MINUTES"]="minut(y)";
$language["SECONDS"]="sekund(y)";
//AJAX Poll System Hack Stop
?>