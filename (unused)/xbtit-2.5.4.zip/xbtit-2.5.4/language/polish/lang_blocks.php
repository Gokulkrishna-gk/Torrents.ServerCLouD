<?php
$language["BLOCK_USER"]="Info o użytkowniku";
$language["BLOCK_INFO"]="Info o trackerze";
$language["BLOCK_MAINMENU"]="";
# We leave this name (drop down menu) blank so it doesnt use the block head showing its name, it looks unsightly and non professional imho!! TreetopClimber 
$language["BLOCK_DDMENU"]="";
$language["BLOCK_MENU"]="Menu Główne"; # block menu needs the name
$language["BLOCK_CALENDAR"]="Kalendarz"; 
$language["BLOCK_CLOCK"]="Zegar";
$language["BLOCK_FORUM"]="Forum";
$language["BLOCK_LASTMEMBER"]="Ostatnio dodany użytkownik";
$language["BLOCK_ONLINE"]="Online";
$language["BLOCK_ONTODAY"]="Zalogowany dzisiaj";
$language["BLOCK_SHOUTBOX"]="Shout Box";
$language["BLOCK_TOPTORRENTS"]="Najpopularniejsze torrenty";
$language["BLOCK_LASTTORRENTS"]="Ostatnio dodane";
$language["BLOCK_NEWS"]="Najnowsze newsy";
$language["BLOCK_SERVERLOAD"]="Obciążenie serwera";
$language["BLOCK_POLL"]="Ankieta";
$language["BLOCK_SEEDWANTED"]="Torrenty potrzebujące seedów";
$language["BLOCK_PAYPAL"]="Dotacje";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Główny pasek narzędzi trackera";
$language["BLOCK_MAINUSERTOOLBAR"]="Główny pasek narzędzi użytkownika";
$language["WELCOME_LASTUSER"]=" Witamy na naszym trackerze ";
$language["BLOCK_MINCLASSVIEW"]="Minimalna ranga do przeglądania";
$language["BLOCK_MAXCLASSVIEW"]="Maksymalna ranga do przeglądania";
?>