<?php
$language["INSERT_USERNAME"]="Musisz wpisać nazwę użytkownika!";
$language["INSERT_PASSWORD"]="Musisz wpisać hasło!";
?>