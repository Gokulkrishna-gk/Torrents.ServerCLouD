<?php
$language["DELETE_READED"]="Удалить";
$language["USER_LANGUE"]="Язык";
$language["USER_STYLE"]="Стиль";
$language["CURRENTLY_PEER"]="Вы являетесь сидом или личером на одной или нескольких раздач.";
$language["STOP_PEER"]="Вы должны остановить свой клиент.";
$language["USER_PWD_AGAIN"]="Повторите пароль";
$language["EMAIL_FAILED"]="Отправить E-mail не удалось!";
$language["NO_SUBJECT"]="No subject";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>Вы должны ввести пароль для сохранения вышеуказанных настроек.</strong></font>";
$language["ERR_PASS_WRONG"]="Пароль не введен или неверен, не могу обновить профиль.";
$language["MSG_DEL_ALL_PM"]="Если Вы выберети Сообщения которые не прочитаны, они не будут удалены";
$language["ERR_PM_GUEST"]="Извените, но Вы не можете отправить Сообщение себе или гостю!";
?>