<?php
$language["INSERT_USERNAME"]="Вы должны ввести Имя Пользователя!";
$language["INSERT_PASSWORD"]="Вы должны ввести Пароль!";
?>