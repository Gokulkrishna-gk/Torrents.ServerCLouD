<?php
$language["NOT_SHA"]="SHA1 функция не доступна. Вам нужно PHP 4.3.0 или новее.";
$language["NOT_AUTHORIZED_UPLOAD"]="Вы не авторизованы для загрузки!";
$language["FILE_UPLOAD_ERROR_1"]="Не могу прочесть загруженый файл";
$language["FILE_UPLOAD_ERROR_3"]="Размер файла 0 байт";
$language["FACOLTATIVE"]="не обязательно";
$language["FILE_UPLOAD_ERROR_2"]="Ошибка при загрузки файла";
$language["ERR_PARSER"]="Похоже что в Вашем торренте ошибка. Парсер не принял его.";
$language["WRITE_CATEGORY"]="Вы должны указать категорию...";
$language["DOWNLOAD"]="Скачать";
$language["MSG_UP_SUCCESS"]="Загрузка прошла успешно! Торрент был добавлен.";
$language["MSG_DOWNLOAD_PID"]="PID система активна, скачайте торрент с Вашим  PID";
$language["EMPTY_DESCRIPTION"]="Вы должны добавить описание!";
$language["EMPTY_ANNOUNCE"]="Анонс адресс пуст";
$language["FILE_UPLOAD_ERROR_1"]="Не могу прочесть загруженый файл";
$language["FILE_UPLOAD_ERROR_2"]="Загрузка файла неудалась";
$language["FILE_UPLOAD_ERROR_3"]="Размер файла 0 байт";
$language["NO_SHA_NO_UP"]="Загрузка файла не возможна - нет SHA1 функции.";
$language["NOT_SHA"]="SHA1 функция не доступна. Вам нужно PHP 4.3.0 или новее.";
$language["ERR_PARSER"]="Похоже что в Вашем торренте ошибка. Парсер не принял его.";
$language["WRITE_CATEGORY"]="Вы должны указать категорию...";
$language["ERR_HASH"]="Info hash ДОЛЖЕН быть точно 40 hex байтов.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Внешние торренты запрещены";
$language["ERR_MOVING_TORR"]="Ошибка перемещения торрента...";
$language["ERR_ALREADY_EXIST"]="Похоже такой торрент уже есть в нашей БД.";
$language["MSG_DOWNLOAD_PID"]="PID система активна, скачайте торрент с Вашим PID";
$language["MSG_UP_SUCCESS"]="Загрузка прошла успешно! Торрент был добавлен.";

?>