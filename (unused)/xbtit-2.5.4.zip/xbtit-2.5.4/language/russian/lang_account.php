<?php
$language["ACCOUNT_CREATED"]="Профиль Создан";
$language["USER_NAME"]="Имя Пользователя";
$language["USER_PWD"]="Пароль";
$language["USER_PWD_AGAIN"]="Пароль еще раз";
$language["USER_STYLE"]="Стиль";
$language["USER_LANGUE"]="Язык";
$language["IMAGE_CODE"]="Код картинки";
$language["INSERT_USERNAME"]="Вы должны ввести Имя Пользователя!";
$language["INSERT_PASSWORD"]="Вы должны ввести Пароль!";
$language["DIF_PASSWORDS"]="Введенные пароли не совпадают!";
$language["ERR_NO_EMAIL"]="E-mail адресс не коректен!";
$language["USER_EMAIL_AGAIN"]="E-mail еще раз";
$language["ERR_NO_EMAIL_AGAIN"]="E-mail еще раз";
$language["DIF_EMAIL"]="E-mail адресса не совпадают!";
$language["SECURITY_CODE"]="Ответьте на Вопрос";
# Password strength
$language["WEEK"]="Слабый";
$language["MEDIUM"]="Средний";
$language["SAFE"]="Безопасный";
$language["STRONG"]="Строгий";

?>