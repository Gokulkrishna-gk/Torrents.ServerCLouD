<?php
$language["BLOCK_USER"]="Инфо Пользователя";
$language["BLOCK_INFO"]="Инфо Трекера";
$language["BLOCK_MENU"]="Главное Меню";
$language["BLOCK_CLOCK"]="Время";
$language["BLOCK_FORUM"]="Форум";
$language["BLOCK_LASTMEMBER"]="Последний пользователь";
$language["BLOCK_ONLINE"]="Пользователи Онлайн";
$language["BLOCK_ONTODAY"]="Сегодня Были";
$language["BLOCK_SHOUTBOX"]="Кричалка";
$language["BLOCK_TOPTORRENTS"]="Лутшие Торренты";
$language["BLOCK_LASTTORRENTS"]="Последние Загрузки";
$language["BLOCK_NEWS"]="Последние Новости";
$language["BLOCK_SERVERLOAD"]="Нагрузка Сервера";
$language["BLOCK_POLL"]="Опрос";
$language["BLOCK_SEEDWANTED"]="Требуются Сиды";
$language["BLOCK_PAYPAL"]="Поддержи Нас";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Main Tracker Toolbar";
$language["BLOCK_MAINUSERTOOLBAR"]="Main User Toolbar";
$language["WELCOME_LASTUSER"]=" Добро пожаловать на трекер ";
$language["BLOCK_MINCLASSVIEW"]="Минимальный ранк для просмотра";
$language["BLOCK_MAXCLASSVIEW"]="Максимальный ранк для просмотра";
?>