<?php
$language["BLOCK_USER"]="Benutzer Info";
$language["BLOCK_INFO"]="Tracker Info";
$language["BLOCK_MENU"]="Haupt Menü";
$language["BLOCK_CLOCK"]="Uhr";
$language["BLOCK_FORUM"]="Forum";
$language["BLOCK_LASTMEMBER"]="Neuestes Mitglied";
$language["BLOCK_ONLINE"]="Online";
$language["BLOCK_ONTODAY"]="Online Heute";
$language["BLOCK_SHOUTBOX"]="Das schwarze Brett";
$language["BLOCK_TOPTORRENTS"]="Top Torrents";
$language["BLOCK_LASTTORRENTS"]="Neueste Torrents";
$language["BLOCK_NEWS"]="News";
$language["BLOCK_SERVERLOAD"]="Server Auslastung";
$language["BLOCK_POLL"]="Umfrage";
$language["BLOCK_SEEDWANTED"]=" Bitte füttert uns ! ";
$language["BLOCK_PAYPAL"]="Wir brauchen Eure Unterstützung";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Tracker Hauptleiste";
$language["BLOCK_MAINUSERTOOLBAR"]="Benutzer Hauptleiste";
$language["WELCOME_LASTUSER"]=" Willkommen bei unserem Tracker ";
$language["BLOCK_MINCLASSVIEW"]="Ansicht tiefste Einstufung";
$language["BLOCK_MAXCLASSVIEW"]="Ansicht höchste Einstufung";
$language["BLOCK_SPONSORS"]="Sponsoren";
$language["BLOCK_PAYPAL"]="Spenden";
?>