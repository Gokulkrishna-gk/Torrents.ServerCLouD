<?php
$language['ERR_NO_EMAIL']='Du skal angive en email adresse';
$language['ERR_INV_EMAIL']='Du skal indtaste en gyldig email';
$language['ERR_NO_CAPTCHA']='Du skal indtaste ImageCode koden';
$language['IMAGE_CODE']='Kode';
$language['SECURITY_CODE']='Svar på spørgsmålet';
$language['RECOVER_EMAIL_1']="\n".'Du har bedt om at dit kodeord resettes.'."\n\n".'Anmodningen kom fra %s.'."\n\n".'Hvis dette ikke var dig, så slet venligst emailen.'."\n\n".'Hvis du vil ændre dit kodeord så klik venligst på dette link:'."\n\n".'%s'."\n\n".'Efter du har gjort dette vil dit nye kodeord blive sendt til dig.'."\n--\n".'%s';
$language['RECOVER_EMAIL_2']="\n".'Systemet har lavet et nyt kodeord til dig.'."\n\n".'Du kan nu logge ind med følgende information:'."\n\n\t".'Brugernavn: %s'."\n\n\t".'Kodeord: %s'."\n\n".'Husk at ændre dit kodeord';
?>