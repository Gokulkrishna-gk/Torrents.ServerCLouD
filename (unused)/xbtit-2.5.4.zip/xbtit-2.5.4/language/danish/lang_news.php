<?php
$language['ERR_NO_TITLE']='Du skal angive en titel til dine nyheder';
?>