<?php
$language['BLOCK_USER']='Bruger info';
$language['BLOCK_INFO']='Tracker info';
$language['BLOCK_MENU']='Hoved menu';
/* We leave this name (drop down menu) blank so it doesnt use the block head showing its name, it looks unsightly and non professional imho!! TreetopClimber */
$language['BLOCK_DDMENU']='';
$language['BLOCK_CALENDAR']='Kalender'; 
$language['BLOCK_CLOCK']='Lokal tid';
$language['BLOCK_FORUM']='Forum';
$language['BLOCK_LASTMEMBER']='Nyeste medlem';
$language['BLOCK_ONLINE']='Online';
$language['BLOCK_ONTODAY']='Online i dag';
$language['BLOCK_SHOUTBOX']='Shout box';
$language['BLOCK_TOPTORRENTS']='Top torrents';
$language['BLOCK_LASTTORRENTS']='Nyeste upload';
$language['BLOCK_NEWS']='Sidste nyhed';
$language['BLOCK_SERVERLOAD']='Server Load';
$language['BLOCK_POLL']='Poll';
$language['BLOCK_SEEDWANTED']='Torrents der mangler seed';
$language['BLOCK_PAYPAL']='Støt siden';
$language['BLOCK_MAINTRACKERTOOLBAR']='Tracker værktøjslinie';
$language['BLOCK_MAINUSERTOOLBAR']='Bruger værktøjslinie';
$language['WELCOME_LASTUSER']='Velkommen til';
$language['BLOCK_MINCLASSVIEW']='Minimum rank der kan se';
$language['BLOCK_MAXCLASSVIEW']='Maximum rank der kan se';
$language["BLOCK_CAT"]="Kategorier";?>