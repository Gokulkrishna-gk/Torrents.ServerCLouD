<?php
$language["INSERT_USERNAME"]="Deves inserir um nome de utilizador.";
$language["INSERT_PASSWORD"]="Deves inserir uma senha.";
?>