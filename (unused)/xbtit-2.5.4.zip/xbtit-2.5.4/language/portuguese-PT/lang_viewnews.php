<?php

// VIEWNEWS.PHP ARQUIVO DE IDIOMA

$language["POSTED_BY"]   = "Postado por";
$language["POSTED_DATE"] = "Postado em";
$language["TITLE"]       = "Título";
$language["ADD"]         = "Adicionar";

?>