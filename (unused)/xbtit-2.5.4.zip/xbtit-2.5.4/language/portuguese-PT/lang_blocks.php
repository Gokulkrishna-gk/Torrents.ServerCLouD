<?php
$language["BLOCK_USER"]="Utilizador";
$language["BLOCK_INFO"]="Tracker";
$language["BLOCK_MENU"]="Menu Principal";
$language["BLOCK_CLOCK"]="Relógio";
$language["BLOCK_FORUM"]="Fórum";
$language["BLOCK_LASTMEMBER"]="Último Membro";
$language["BLOCK_ONLINE"]="Online";
$language["BLOCK_ONTODAY"]="Online Hoje";
$language["BLOCK_SHOUTBOX"]="Caixa de Mensagens";
$language["BLOCK_TOPTORRENTS"]="Torrents mais populares";
$language["BLOCK_LASTTORRENTS"]="Últimas torrents";
$language["BLOCK_NEWS"]="Últimas notícias";
$language["BLOCK_SERVERLOAD"]="Carga do servidor";
$language["BLOCK_POLL"]="Sondagem";
$language["BLOCK_SEEDWANTED"]="Torrents sem sementes";
$language["BLOCK_PAYPAL"]="Doações";
$language["BLOCK_MAINTRACKERTOOLBAR"]="	Barra de ferramentas principal do tracker";
$language["BLOCK_MAINUSERTOOLBAR"]="	Barra de ferramentas principal do utilizador";
$language["WELCOME_LASTUSER"]=" Bem-vindo ao nosso tracker ";
$language["BLOCK_MINCLASSVIEW"]="Rank mínimo que pode visualizar";
$language["BLOCK_MAXCLASSVIEW"]="Rank máximo que pode visualizar";
?>