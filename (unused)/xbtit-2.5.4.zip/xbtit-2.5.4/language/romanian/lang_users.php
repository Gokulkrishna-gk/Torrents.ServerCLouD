<?php
// ENGLISH USERS.PHP FILE
$language['FIND_USER']='Cautare Utilizator';
$language['USER_LEVEL']='Rang Utilizator';
$language['ALL']='Toate';
$language['SEARCH']='Caută';
$language['USER_NAME']='Nume';
$language['USER_LEVEL']='Rang';
$language['USER_JOINED']='Înscris la';
$language['USER_LASTACCESS']='Ultima accesare';
$language['USER_COUNTRY']='Ţara';
$language['RATIO']='Raţie';
$language['USERS_PM']='PM';
$language['EDIT']='Editează';
$language['DELETE']='Şterge';
$language['NO_USERS_FOUND']='Nici un utilizatoe găsit!';
$language['UNKNOWN']='Necunoscută';
?>