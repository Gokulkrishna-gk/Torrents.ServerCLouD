<?php
$language['INSERT_USERNAME']='Trebuie să-ţi alegi un nume de utilizator!';
$language['INSERT_PASSWORD']='Trebuie să-ţi alegi o parolă!';
?>