<?php
$language["NOT_SHA"]="SHA1 funkcija nije prepoznata. Trebate PHP 4.3.0 pa na vise.";
$language["NOT_AUTHORIZED_UPLOAD"]="Nemate autorizacije za upload!";
$language["FILE_UPLOAD_ERROR_1"]="Greska u uploadovanom torrentu";
$language["FILE_UPLOAD_ERROR_2"]="Fajl Upload greska";
$language["FILE_UPLOAD_ERROR_3"]="File je 0 bytes";
$language["FACOLTATIVE"]="opcionalno";
$language["ERR_PARSER"]="Cini se na nesto nije uredu sa torrentom koji pokusavate uploadovati. Parser ga nije prihvatio.";
$language["WRITE_CATEGORY"]="Odaberite torrent kategoriju...";
$language["DOWNLOAD"]="Download";
$language["MSG_UP_SUCCESS"]="Upload uspjesan! Torrent je uspjesno sacuvan.";
$language["MSG_DOWNLOAD_PID"]="PID sistem je aktivan, sada sacuvajte torrent sa vasim PID-om";
$language["EMPTY_DESCRIPTION"]="Opis je obavezan!";
$language["EMPTY_ANNOUNCE"]="Announce torrenta je prazan";
$language["NO_SHA_NO_UP"]="SHA1 funkcija nije prepoznata. Trebate PHP 4.3.0 pa na vise.";
$language["ERR_HASH"]="Greska u info hashu torrenta, napravite novi";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Samo privatni announce je dozvoljen, spoljasnji su zabranjeni";
$language["ERR_MOVING_TORR"]="Greska zapisa torrenta u torrent direktorijum...";
$language["ERR_ALREADY_EXIST"]="Cini se da ovaj torrent vec postoji u nasoj arhivi.";
?>