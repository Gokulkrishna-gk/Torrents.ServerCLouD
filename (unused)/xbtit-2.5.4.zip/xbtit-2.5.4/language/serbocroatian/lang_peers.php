<?php
$language["PEER_PROGRESS"]="Progres";
$language["PEER_COUNTRY"]="Zemlja";
$language["PEER_PORT"]="Port";
$language["PEER_STATUS"]="Status";
$language["PEER_CLIENT"]="Klijent";
$language["NO_PEERS"]="Nema aktivnih (peers)";
?>