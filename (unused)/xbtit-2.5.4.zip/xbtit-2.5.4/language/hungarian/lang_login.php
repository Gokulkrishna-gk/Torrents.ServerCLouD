<?php
$language["INSERT_USERNAME"]="Írd be a felhasználói Neved!";
$language["INSERT_PASSWORD"]="Írd be a felhasználói jelszavad!";
?>