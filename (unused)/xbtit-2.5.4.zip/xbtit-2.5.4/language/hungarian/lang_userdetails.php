<?php

// USERDETAILS.PHP LANGUAGE FILE

$language["USERNAME"]           = "Felh.név";
$language["EMAIL"]              = "Email";
$language["LAST_IP"]            = "Utolsó Ip";
$language["USER_LEVEL"]         = "Rang";
$language["USER_JOINED"]        = "Csatlakozott";
$language["USER_LASTACCESS"]    = "Legutóbb itt volt";
$language["PEER_COUNTRY"]       = "Ország";
$language["USER_LOCAL_TIME"]    = "Helyi idő";
$language["DOWNLOADED"]         = "letöltött";
$language["UPLOADED"]           = "Feltöltött";
$language["RATIO"]              = "Arány";
$language["FORUM"]              = "Fórum";
$language["POSTS"]              = "Üzenetek";
$language["POSTS_PER_DAY"]      = "%s átlag üzi naponta";
$language["TORRENTS"]           = "Torrentek";
$language["FILE"]               = "File-k";
$language["ADDED"]              = "Hozzáadva";
$language["SIZE"]               = "Méret";
$language["SHORT_S"]            = "S";
$language["SHORT_L"]            = "L";
$language["SHORT_C"]            = "C";
$language["NO_TORR_UP_USER"]    = "A felhasználónak nincs feltöltött torrentje!";
$language["ACTIVE_TORRENT"]     = "Aktiv Torrentek";
$language["PEER_STATUS"]        = "Státusz";
$language["NO_ACTIVE_TORR"]     = "Nincsenek aktív torrentek";
$language["PEER_CLIENT"]        = "Kliens";
$language["EDIT"]               = "Módosít";
$language["DELETE"]             = "Töröl";
$language["PM"]                 = "PM";
$language["BACK"]               = "Vissza";
$language["NO_HISTORY"]         = "Nincs történet...";
?>