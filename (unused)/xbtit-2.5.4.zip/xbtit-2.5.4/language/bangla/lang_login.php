<?php
$language['INSERT_USERNAME']='আপনার ব্যাবহার করা নাম প্রবেশ করুন!';
$language['INSERT_PASSWORD']='আপনার গোপন কোড অবশ্যই ব্যাবহার করুন!';
?>