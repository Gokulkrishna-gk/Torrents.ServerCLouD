<?php
$language['BLOCK_USER']='ব্যাবহারকারির তথ্য';
$language['BLOCK_INFO']='টোরেন্ট তথ্য';
$language['BLOCK_MENU']='মুল পাতা';
/* We leave this name (drop down menu) blank so it doesnt use the block head showing its name, it looks unsightly and non professional imho!! TreetopClimber */
$language['BLOCK_DDMENU']='';
$language['BLOCK_CALENDAR']='দিনপুঞ্জিকা'; 
$language['BLOCK_CLOCK']='ঘড়ি';
$language['BLOCK_FORUM']='ফোরাম';
$language['BLOCK_LASTMEMBER']='সর্বশেষ অতিথি';
$language['BLOCK_ONLINE']='অনলাইনে আছেন';
$language['BLOCK_ONTODAY']='আজ সারাদিন';
$language['BLOCK_SHOUTBOX']='চিৎকার';
$language['BLOCK_TOPTORRENTS']='Top টোরেন্ট';
$language['BLOCK_LASTTORRENTS']='সর্বশেষ Upload';
$language['BLOCK_NEWS']='বর্তমান সংবাদ';
$language['BLOCK_SERVERLOAD']='সারভার লোড';
$language['BLOCK_POLL']='ভোটের তালিকা';
$language['BLOCK_SEEDWANTED']='সীড প্রয়োজন';
$language['BLOCK_PAYPAL']='সাথে থাকুন';
$language['BLOCK_MAINTRACKERTOOLBAR']='Main Tracker Toolbar';
$language['BLOCK_MAINUSERTOOLBAR']='Main User Toolbar';
$language['WELCOME_LASTUSER']=' স্বাগতম আমাদের সাইটে ';
$language['BLOCK_MINCLASSVIEW']='নিম্মস্তর এর বাবহারকারী থেকে';
$language['BLOCK_MAXCLASSVIEW']='উচ্চওস্তর এর বাবহারকারী পর্যন্ত';
?>