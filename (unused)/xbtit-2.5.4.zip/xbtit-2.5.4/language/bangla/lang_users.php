<?php

// ENGLISH USERS.PHP FILE

$language['FIND_USER']       = 'খোঁজ';
$language['USER_LEVEL']      = 'ব্যাবহারকারির পদ';
$language['ALL']             = 'সকল সদস্য';
$language['SEARCH']          = 'খুঁজুন';
$language['USER_NAME']       = 'ব্যাবহারকারির নাম';
$language['USER_LEVEL']      = 'ব্যাবহারকারির পদ';
$language['USER_JOINED']     = 'আমাদের সাথে যোগ দিয়েছে';
$language['USER_LASTACCESS'] = 'সর্বশেষ দেখা';
$language['USER_COUNTRY']    = 'দেশ';
$language['RATIO']           = 'মূল্যায়ন পয়েন্ট';
$language['USERS_PM']        = 'চিঠি';
$language['EDIT']            = 'সম্পাদন';
$language['DELETE']          = 'মুছেফেলো';
$language['NO_USERS_FOUND']  = 'কেউ নেই!';
$language['UNKNOWN']         = 'অপরিচিত';

?>