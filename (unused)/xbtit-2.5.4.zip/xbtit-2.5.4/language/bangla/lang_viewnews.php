<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language['POSTED_BY']   = 'মন্তব্য করেছে';
$language['POSTED_DATE'] = 'তারিখ';
$language['TITLE']       = 'বিষয়';
$language['ADD']         = 'যোগ ';

?>
