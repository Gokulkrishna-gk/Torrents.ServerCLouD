<?php
//中文翻译:ziggear 
//你可以自由修改和发布，但不要删除注释和作者信息。

$language['USERNAME']           = '用户名';
$language['EMAIL']              = 'Email';
$language['LAST_IP']            = '最后访问IP';
$language['USER_LEVEL']         = '用户组';
$language['USER_JOINED']        = '注册日期';
$language['USER_LASTACCESS']    = '最后访问';
$language['PEER_COUNTRY']       = '来自';
$language['USER_LOCAL_TIME']    = '用户当地时间';
$language['DOWNLOADED']         = '下载';
$language['UPLOADED']           = '上传';
$language['RATIO']              = '上传/下载';
$language['FORUM']              = '论坛';
$language['POSTS']              = '发帖数';
$language['POSTS_PER_DAY']      = '日均 %s 帖';
$language['TORRENTS']           = '种子';
$language['FILE']               = '文件名';
$language['ADDED']              = '上传日期';
$language['SIZE']               = '大小';
$language['SHORT_S']            = 'S';
$language['SHORT_L']            = 'L';
$language['SHORT_C']            = 'C';
$language['NO_TORR_UP_USER']    = '该用户没有上传任何种子!';
$language['ACTIVE_TORRENT']     = '活动种子';
$language['PEER_STATUS']        = '状态';
$language['NO_ACTIVE_TORR']     = '暂时没有活动种子';
$language['PEER_CLIENT']        = '客户端';
$language['EDIT']               = '编辑';
$language['DELETE']             = '删除';
$language['PM']                 = '站内信';
$language['BACK']               = '返回';
$language['NO_HISTORY']         = '暂时没有历史';
$language['GUEST_DETAILS']      = '访客没有查看用户资料的权限!';
?>