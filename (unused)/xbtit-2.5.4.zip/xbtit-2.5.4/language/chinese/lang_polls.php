<?php
//中文翻译:ziggear 
//你可以自由修改和发布，但不要删除注释和作者信息。

//AJAX Poll System Hack Start - 5:03 PM 3/24/2007
$language['POLL_ID']='ID';
$language['LATEST_POLL']='最新调查';
$language['CAST_VOTE']='投下我的一票';
$language['FETCHING_RESULTS']='读取调查结果中. 请稍候...';
$language['POLL_TITLE']='调查主题';
$language['POLL_TITLE_MISSING']='调查主题丢失...';
$language['POLLING_SYSTEM']='AJAX 调查系统';
$language['CURRENT_POLLS']='查看当前调查项目';
$language['POLL_STARTED']='开始于';
$language['POLL_ENDED']='结束于';
$language['POLL_LASTED']='最后回复';
$language['POLL_BY']='调查发起人';
$language['POLL_VOTES']='得票数';
$language['POLL_STILL_ACTIVE']='目前可用';
$language['POLL_NEW']='新调查';
$language['POLL_START_NEW']='发起新调查';
$language['POLL_ACTIVE']='是否可用';
$language['POLL_ACTIVE_TRUE']='可用';
$language['POLL_ACTIVE_FALSE']='不可用';
$language['POLL_OPTION']='选项';
$language['POLL_OPTIONS']='选项';
$language['POLL_MOVE']='下移';
$language['POLL_NEW_OPTIONS']='新选项';
$language['POLL_SAVE']='保存';
$language['POLL_CANCEL']='取消';
$language['POLL_DELETE']='删除调查';
$language['POLL_DEL_CONFIRM']='确实要删除此调查吗?';
$language['POLL_VOTERS']='参与调查的用户';
$language['POLL_IP_ADDRESS']='IP地址';
$language['POLL_DATE']='投票日期';
$language['POLL_USER']='投票者';
$language['POLL_ACCOUNT_DEL']='<i>已删除</i>';
$language['POLL_BACK']='返回';
$language['YEAR']='年';
$language['MONTH']='月';
$language['WEEK']='周';
$language['DAY']='日';
$language['HOUR']='时';
$language['MINUTE']='分';
$language['SECOND']='秒';
$language['YEARS']='年';
$language['MONTHS']='月';
$language['WEEKS']='周';
$language['DAYS']='日';
$language['HOURS']='时';
$language['MINUTES']='分';
$language['SECONDS']='秒';
//AJAX Poll System Hack Stop
?>