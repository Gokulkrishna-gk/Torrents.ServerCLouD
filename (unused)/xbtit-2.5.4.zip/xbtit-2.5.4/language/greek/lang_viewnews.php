<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Καταχωρήθηκε στις";
$language["POSTED_DATE"] = "Ημερομηνία καταχώρησης";
$language["TITLE"]       = "Τίτλος";
$language["ADD"]         = "Πρόσθεσε";

?>