<?php
$language["BLOCK_USER"]="Πληροφορίες Χρήστη";
$language["BLOCK_INFO"]="Πληροφορίες Tracker";
$language["BLOCK_MENU"]="Κεντρικό μενού";
$language["BLOCK_CLOCK"]="Ρολόϊ";
$language["BLOCK_FORUM"]="Forum";
$language["BLOCK_LASTMEMBER"]="Τελευταίο μέλος";
$language["BLOCK_ONLINE"]="Online";
$language["BLOCK_ONTODAY"]="Για σήμερα";
$language["BLOCK_SHOUTBOX"]="Shout Box";
$language["BLOCK_TOPTORRENTS"]="Τα καλύτερα Torrents";
$language["BLOCK_LASTTORRENTS"]="Το τελευταίο Upload";
$language["BLOCK_NEWS"]="Τελευταία νέα";
$language["BLOCK_SERVERLOAD"]="Φόρτωμα κεντρικού υπολογιστή";
$language["BLOCK_POLL"]="Ψηφοφορία";
$language["BLOCK_SEEDWANTED"]="Δώσε (Seed) στα επιθυμητά Torrents";
$language["BLOCK_PAYPAL"]="Υποστηρίξτε μας";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Εργαλειοθήκη κεντρικού Tracker";
$language["BLOCK_MAINUSERTOOLBAR"]="Κεντρική εργαλειοθήκη χρήστη";
$language["WELCOME_LASTUSER"]=" Καλώς ήρθατε στο νέο μας Tracker ";
$language["BLOCK_MINCLASSVIEW"]="Ο ελάχιστος βαθμός μπορεί να δει";
$language["BLOCK_MAXCLASSVIEW"]="Ο μέγιστος βαθμός μπορεί να δει";
?>