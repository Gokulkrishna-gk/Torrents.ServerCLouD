<?php
$language["PEER_PROGRESS"]="Πρόοδος";
$language["PEER_COUNTRY"]="Χώρα";
$language["PEER_PORT"]="Θύρα";
$language["PEER_STATUS"]="Κατάσταση";
$language["PEER_CLIENT"]="Πελάτης";
$language["NO_HISTORY"]="Δεν υπάρχει ιστορικό για να δείς";
?>