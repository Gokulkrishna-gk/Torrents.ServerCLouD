<?php
$language["PEER_PROGRESS"]="Πρόοδος";
$language["PEER_COUNTRY"]="Χώρα";
$language["PEER_PORT"]="Θύρα";
$language["PEER_STATUS"]="Κατάσταση";
$language["PEER_CLIENT"]="πελάτης";
$language["NO_PEERS"]="No peers";
?>