<?php
$language["PEER_PROGRESS"]="Progrès";
$language["PEER_COUNTRY"]="Pays";
$language["PEER_PORT"]="Port";
$language["PEER_STATUS"]="Statut";
$language["PEER_CLIENT"]="Client";
$language["NO_HISTORY"]="Aucun historique à afficher";
?>