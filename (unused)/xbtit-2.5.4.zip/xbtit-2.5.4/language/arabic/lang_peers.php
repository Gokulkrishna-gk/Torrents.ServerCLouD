<?php
$language['PEER_PROGRESS']='التقدم';
$language['PEER_COUNTRY']='الدولة';
$language['PEER_PORT']='المنفذ';
$language['PEER_STATUS']='الحالة';
$language['PEER_CLIENT']='البرنامج';
$language['NO_PEERS']='لايوجد مشاركين';
?>