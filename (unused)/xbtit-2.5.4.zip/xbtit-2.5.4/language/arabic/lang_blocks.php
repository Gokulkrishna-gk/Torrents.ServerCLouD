<?php
$language['BLOCK_USER']='معلومات المستخدم';
$language['BLOCK_INFO']='معلومات المتتبع';
$language['BLOCK_MENU']='القائمة الرئيسية';
/* We leave this name (drop down menu) blank so it doesnt use the block head showing its name, it looks unsightly and non professional imho!! TreetopClimber */
$language['BLOCK_DDMENU']='';
$language['BLOCK_CALENDAR']='التقويم'; 
$language['BLOCK_CLOCK']='الساعة';
$language['BLOCK_FORUM']='المنتدى';
$language['BLOCK_LASTMEMBER']='آخر عضو مسجل';
$language['BLOCK_ONLINE']='من على الخط';
$language['BLOCK_ONTODAY']='في هذا اليوم';
$language['BLOCK_SHOUTBOX']='الدردشة';
$language['BLOCK_TOPTORRENTS']='اشهر التورنتات';
$language['BLOCK_LASTTORRENTS']='آخر المرفوعات';
$language['BLOCK_NEWS']='آخر الاخبار';
$language['BLOCK_SERVERLOAD']='ضغط الخادم';
$language['BLOCK_POLL']='استفتاء';
$language['BLOCK_SEEDWANTED']='تورنتات محتاجة لسيدرس';
$language['BLOCK_PAYPAL']='إعلانات تجارية';
$language['BLOCK_MAINTRACKERTOOLBAR']='شريط المتتبع الرسمي';
$language['BLOCK_MAINUSERTOOLBAR']='شريط المستخدم الرسمي';
$language['WELCOME_LASTUSER']=' مرحبا بك الى المتتبع ';
$language['BLOCK_MINCLASSVIEW']='ادنى رتبه من الاعضاء يمكنها مشاهدة البلوك';
$language['BLOCK_MAXCLASSVIEW']='اعلى رتبه من الاعضاء يمكنها مشاهدة البلوك';
?>