<?php
$language['INSERT_USERNAME']='عليك ادخال اسم مستخدم';
$language['INSERT_PASSWORD']='عليك ادخال كلمة السر';
?>