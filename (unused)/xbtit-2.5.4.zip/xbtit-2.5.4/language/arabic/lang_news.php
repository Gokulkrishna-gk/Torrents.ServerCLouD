<?php
$language['ERR_NO_TITLE']='عليك ادخال عنوان لهذا الخبر';
?>