<?php
$language['BLOCK_USER']='User Info';
$language['BLOCK_INFO']='Tracker Info';
$language['BLOCK_MAINMENU']=''; # this is the Main Menu no name needed, some dipshit took this out ... not nice!!
# We leave this name (drop down menu) blank so it doesnt use the block head showing its name, it looks unsightly and non professional imho!! TreetopClimber 
$language['BLOCK_DDMENU']='';
$language['BLOCK_MENU']='Main Menu'; # block menu needs the name
$language['BLOCK_CALENDAR']='Calendar'; 
$language['BLOCK_CLOCK']='Clock';
$language['BLOCK_FORUM']='Forum';
$language['BLOCK_LASTMEMBER']='Latest Member';
$language['BLOCK_ONLINE']='Online';
$language['BLOCK_ONTODAY']='On Today';
$language['BLOCK_SHOUTBOX']='Shout Box';
$language['BLOCK_TOPTORRENTS']='Top Torrents';
$language['BLOCK_LASTTORRENTS']='Last Upload';
$language['BLOCK_NEWS']='Last News';
$language['BLOCK_SERVERLOAD']='Server Load';
$language['BLOCK_POLL']='Poll';
$language['BLOCK_SEEDWANTED']='Seed Wanted Torrents';
$language['BLOCK_PAYPAL']='Support US';
$language['BLOCK_MAINTRACKERTOOLBAR']='Main Tracker Toolbar';
$language['BLOCK_MAINUSERTOOLBAR']='Main User Toolbar';
$language['WELCOME_LASTUSER']=' Welcome to our Tracker ';
$language['BLOCK_MINCLASSVIEW']='Minimum rank that can view';
$language['BLOCK_MAXCLASSVIEW']='Maximum rank that can view';
?>