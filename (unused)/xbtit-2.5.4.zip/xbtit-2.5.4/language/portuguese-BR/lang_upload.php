<?php
$language["NOT_SHA"]="SHA1 função não disponível. Você precisa PHP 4.3.0 ou superior.";
$language["NOT_AUTHORIZED_UPLOAD"]="Você não está autorizado a fazer upload!";
$language["FILE_UPLOAD_ERROR_1"]="Não pode ler o arquivo enviado";
$language["FILE_UPLOAD_ERROR_3"]="O arquivo tem zero de tamanho";
$language["FACOLTATIVE"]="Opcional";
$language["FILE_UPLOAD_ERROR_2"]="Erro ao enviar arquivo";
$language["ERR_PARSER"]="Parece haver um erro no seu torrent. O parser não aceita isto.";
$language["WRITE_CATEGORY"]="Você deve especificar a categoria do torrent...";
$language["DOWNLOAD"]="Download";
$language["MSG_UP_SUCCESS"]="Enviado com sucesso! O torrente foi adicionado.";
$language["MSG_DOWNLOAD_PID"]="Sistema PID activo obter seu torrent com seu PID";
$language["EMPTY_DESCRIPTION"]="Você deve digitar uma descrição!";
$language["EMPTY_ANNOUNCE"]="Announce está vazio";
$language["FILE_UPLOAD_ERROR_1"]="Não pode ler o arquivo carregado";
$language["FILE_UPLOAD_ERROR_2"]="Erro ao enviar arquivo";
$language["FILE_UPLOAD_ERROR_3"]="O arquivo tem zero de tamanho";
$language["NO_SHA_NO_UP"]="Arquivo enviado não disponível - Nenhuma função SHA1.";
$language["NOT_SHA"]="Função SHA1 não disponível. Você precisa PHP 4.3.0 ou superior.";
$language["ERR_PARSER"]="Parece haver um erro no seu torrent. O parser não aceita isto.";
$language["WRITE_CATEGORY"]="Você deve especificar a categoria do torrent...";
$language["ERR_HASH"]="Info. hash deve ser exactamente 40 hex bytes.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Torrents externos não são permitidos";
$language["ERR_MOVING_TORR"]="Erro movendo torrent...";
$language["ERR_ALREADY_EXIST"]="Este torrent pode já existir em nosso banco de dados.";
$language["MSG_DOWNLOAD_PID"]="Sistema PID ativo obter seu torrent com seu PID";
$language["MSG_UP_SUCCESS"]="Enviado com sucesso! O torrente foi adicionado.";

?>
