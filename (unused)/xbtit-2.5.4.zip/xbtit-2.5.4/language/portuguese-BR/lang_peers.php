<?php
$language["PEER_PROGRESS"]="Progresso";
$language["PEER_COUNTRY"]="País";
$language["PEER_PORT"]="Porta";
$language["PEER_STATUS"]="Status";
$language["PEER_CLIENT"]="Cliente";
$language["NO_PEERS"]="Sem fontes";
?>
